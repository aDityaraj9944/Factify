package com.example.factify

data class Fact(
    val fact: String
)
