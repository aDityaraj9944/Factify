package com.example.factify

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class FavoriteDatabase(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "factify.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_FAVORITES = "favorites"
        private const val COLUMN_ID = "id"
        private const val COLUMN_FACT = "fact"
        private const val COLUMN_TIMESTAMP = "timestamp"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTable = """
            CREATE TABLE $TABLE_FAVORITES (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_FACT TEXT NOT NULL,
                $COLUMN_TIMESTAMP INTEGER NOT NULL
            )
        """.trimIndent()
        db?.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_FAVORITES")
        onCreate(db)
    }

    // Add a favorite fact
    fun addFavorite(fact: String): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_FACT, fact)
            put(COLUMN_TIMESTAMP, System.currentTimeMillis())
        }
        return db.insert(TABLE_FAVORITES, null, values)
    }

    // Get all favorites
    fun getAllFavorites(): MutableList<String> {
        val favorites = mutableListOf<String>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_FAVORITES,
            arrayOf(COLUMN_FACT),
            null,
            null,
            null,
            null,
            "$COLUMN_TIMESTAMP DESC"
        )

        if (cursor.moveToFirst()) {
            do {
                val fact = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_FACT))
                favorites.add(fact)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return favorites
    }

    // Check if fact exists
    fun isFavorite(fact: String): Boolean {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_FAVORITES,
            arrayOf(COLUMN_ID),
            "$COLUMN_FACT = ?",
            arrayOf(fact),
            null,
            null,
            null
        )
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    // Remove a favorite
    fun removeFavorite(fact: String): Int {
        val db = writableDatabase
        return db.delete(TABLE_FAVORITES, "$COLUMN_FACT = ?", arrayOf(fact))
    }

    // Get count of favorites
    fun getFavoritesCount(): Int {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT COUNT(*) FROM $TABLE_FAVORITES", null)
        cursor.moveToFirst()
        val count = cursor.getInt(0)
        cursor.close()
        return count
    }

    // Clear all favorites
    fun clearAllFavorites() {
        val db = writableDatabase
        db.delete(TABLE_FAVORITES, null, null)
    }
}