package com.example.factify

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FavoritesAdapter(
    private val favList: MutableList<String>,
    private val onRemoveClick: (Int) -> Unit
) : RecyclerView.Adapter<FavoritesAdapter.FavVH>() {

    inner class FavVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val factText: TextView = itemView.findViewById(R.id.favFactText)
        val removeBtn: ImageButton? = itemView.findViewById(R.id.removeBtn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavVH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_favorite, parent, false)
        return FavVH(view)
    }

    override fun onBindViewHolder(holder: FavVH, position: Int) {
        val fact = favList[position]
        holder.factText.text = fact

        holder.removeBtn?.setOnClickListener {
            val adapterPosition = holder.adapterPosition
            if (adapterPosition != RecyclerView.NO_POSITION) {
                onRemoveClick(adapterPosition)
            }
        }
    }

    override fun getItemCount(): Int = favList.size
}