        package com.example.factify

        import retrofit2.http.GET
        import retrofit2.http.Headers
        interface FactApiService {
            @Headers("X-Api-Key: xks7IDGakya7Z5Z9iPdELQ==mM7TWu6caMTK5jBU")
            @GET("facts")
            suspend fun getRandomFact(): List<Fact>
        }
