package com.example.factify

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FactPagerAdapter(
    private val facts: MutableList<String>
) : RecyclerView.Adapter<FactPagerAdapter.FactViewHolder>() {

    // Soft pastel gradient colors for glass effect
    private val colorPalette = listOf(
        "#FFE3F2FD" to "#FF6B9D", // Light Blue with Pink accent
        "#FFF3E5F5" to "#9C27B0", // Light Purple with Purple accent
        "#FFFFF9C4" to "#FFB300", // Light Yellow with Amber accent
        "#FFE0F2F1" to "#00897B", // Light Teal with Teal accent
        "#FFFCE4EC" to "#E91E63", // Light Pink with Pink accent
        "#FFF1F8E9" to "#689F38", // Light Green with Green accent
        "#FFFFF3E0" to "#FB8C00", // Light Orange with Orange accent
        "#FFE8EAF6" to "#5C6BC0", // Light Indigo with Indigo accent
        "#FFFFEBEE" to "#EF5350", // Light Red with Red accent
        "#FFE0F7FA" to "#26C6DA"  // Light Cyan with Cyan accent
    )

    inner class FactViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val factText: TextView = itemView.findViewById(R.id.factText)
        val background: View = itemView.findViewById(R.id.cardBackground)
        val accent: View = itemView.findViewById(R.id.topAccent)
        val gradientOverlay: View = itemView.findViewById(R.id.gradientOverlay)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FactViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_fact_card, parent, false)
        return FactViewHolder(view)
    }

    override fun onBindViewHolder(holder: FactViewHolder, position: Int) {
        holder.factText.text = facts[position]

        // Apply subtle gradient colors
        val colorIndex = position % colorPalette.size
        val (bgColor, accentColor) = colorPalette[colorIndex]

        // Background stays white with transparency, but we can tint the overlay
        holder.gradientOverlay.setBackgroundColor(Color.parseColor(bgColor))
        holder.accent.setBackgroundColor(Color.parseColor(accentColor))

        // Match text color to accent color
        holder.factText.setTextColor(Color.parseColor(accentColor))
    }

    override fun getItemCount(): Int = facts.size

    fun addFact(fact: String) {
        facts.add(fact)
        notifyItemInserted(facts.size - 1)
    }

    fun getFact(position: Int): String {
        return if (position in facts.indices) facts[position] else ""
    }
}