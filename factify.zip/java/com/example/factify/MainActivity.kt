package com.example.factify

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.button.MaterialButton
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var viewPager: ViewPager2
    private lateinit var saveBtn: MaterialButton
    private lateinit var shareBtn: MaterialButton
    private lateinit var viewFavoritesBtn: MaterialButton
    private lateinit var db: FavoriteDatabase

    private lateinit var adapter: FactPagerAdapter
    private val factsList = mutableListOf("Swipe to see an amazing fact!")

    private var isLoadingFact = false

    // Soft pastel gradient colors for glass theme
    private val colorPalette = listOf(
        "#FFE3F2FD" to "#FF6B9D",
        "#FFF3E5F5" to "#9C27B0",
        "#FFFFF9C4" to "#FFB300",
        "#FFE0F2F1" to "#00897B",
        "#FFFCE4EC" to "#E91E63",
        "#FFF1F8E9" to "#689F38",
        "#FFFFF3E0" to "#FB8C00",
        "#FFE8EAF6" to "#5C6BC0",
        "#FFFFEBEE" to "#EF5350",
        "#FFE0F7FA" to "#26C6DA"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize database
        db = FavoriteDatabase(this)

        viewPager = findViewById(R.id.factViewPager)
        saveBtn = findViewById(R.id.saveFactBtn)
        shareBtn = findViewById(R.id.shareFactBtn)
        viewFavoritesBtn = findViewById(R.id.viewFavoritesBtn)

        adapter = FactPagerAdapter(factsList)
        viewPager.adapter = adapter
        viewPager.isUserInputEnabled = true
        viewPager.orientation = ViewPager2.ORIENTATION_HORIZONTAL
        viewPager.setPageTransformer(DepthPageTransformer())

        // Load first fact initially
        fetchRandomFact()

        // Listen for swipes
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)

                // Update UI colors
                updateCardColors(position)

                // When user swipes to last visible fact, preload next
                if (position == adapter.itemCount - 1) {
                    fetchRandomFact()
                }
            }
        })

        saveBtn.setOnClickListener {
            val currentPosition = viewPager.currentItem
            val currentFact = adapter.getFact(currentPosition)

            if (currentFact.isNotEmpty() && currentFact != "Swipe to see an amazing fact!") {
                // Check if already saved using database
                if (!db.isFavorite(currentFact)) {
                    // Save to database
                    db.addFavorite(currentFact)

                    // Glass-style snackbar
                    Snackbar.make(it, "✓ Fact saved to favorites!", Snackbar.LENGTH_SHORT)
                        .setBackgroundTint(Color.parseColor("#E600D9A3"))
                        .setTextColor(Color.parseColor("#00897B"))
                        .show()
                } else {
                    Snackbar.make(it, "Already in favorites!", Snackbar.LENGTH_SHORT)
                        .setBackgroundTint(Color.parseColor("#E6FFB300"))
                        .setTextColor(Color.parseColor("#F57F17"))
                        .show()
                }
            } else {
                Snackbar.make(it, "No fact to save!", Snackbar.LENGTH_SHORT)
                    .setBackgroundTint(Color.parseColor("#E6FF6B9D"))
                    .setTextColor(Color.parseColor("#C2185B"))
                    .show()
            }
        }

        shareBtn.setOnClickListener {
            val currentPosition = viewPager.currentItem
            val currentFact = adapter.getFact(currentPosition)

            if (currentFact.isNotEmpty() && currentFact != "Swipe to see an amazing fact!") {
                shareFact(currentFact)
            } else {
                Snackbar.make(it, "No fact to share!", Snackbar.LENGTH_SHORT)
                    .setBackgroundTint(Color.parseColor("#E6FF6B9D"))
                    .setTextColor(Color.parseColor("#C2185B"))
                    .show()
            }
        }

        viewFavoritesBtn.setOnClickListener {
            openFavoritesActivity()
        }
    }

    private fun shareFact(fact: String) {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "✨ Amazing Fact from Factify!\n\n$fact\n\n📱 Get more facts with Factify app!")
            type = "text/plain"
        }
        startActivity(Intent.createChooser(shareIntent, "Share fact via"))
    }

    private fun updateCardColors(position: Int) {
        val colorIndex = position % colorPalette.size
        val (bgColor, accentColor) = colorPalette[colorIndex]

        viewPager.post {
            val recyclerView = viewPager.getChildAt(0) as? androidx.recyclerview.widget.RecyclerView
            recyclerView?.let {
                val viewHolder = it.findViewHolderForAdapterPosition(position)
                viewHolder?.itemView?.let { cardView ->
                    val gradientOverlay = cardView.findViewById<View>(R.id.gradientOverlay)
                    val accent = cardView.findViewById<View>(R.id.topAccent)

                    // Animate gradient overlay color
                    gradientOverlay?.let { overlay ->
                        val currentColor = try {
                            (overlay.background as? android.graphics.drawable.ColorDrawable)?.color
                                ?: Color.parseColor(bgColor)
                        } catch (e: Exception) {
                            Color.parseColor(bgColor)
                        }

                        val newColor = Color.parseColor(bgColor)
                        val colorAnimator =
                            ValueAnimator.ofObject(ArgbEvaluator(), currentColor, newColor)
                        colorAnimator.duration = 300
                        colorAnimator.addUpdateListener { animator ->
                            overlay.setBackgroundColor(animator.animatedValue as Int)
                        }
                        colorAnimator.start()
                    }

                    accent?.setBackgroundColor(Color.parseColor(accentColor))
                }
            }
        }
    }

    private fun openFavoritesActivity() {
        val intent = Intent(this, FavoritesActivity::class.java)
        startActivity(intent)
    }

    private fun fetchRandomFact() {
        if (isLoadingFact) return
        isLoadingFact = true

        lifecycleScope.launch {
            try {
                val facts = RetrofitInstance.api.getRandomFact()
                if (facts.isNotEmpty()) {
                    adapter.addFact(facts[0].fact)
                }
            } catch (e: Exception) {
                Snackbar.make(
                    viewPager,
                    "Failed to load fact 😢 Check your internet",
                    Snackbar.LENGTH_LONG
                ).setBackgroundTint(Color.parseColor("#E6EF5350"))
                    .setTextColor(Color.parseColor("#C62828"))
                    .show()
            } finally {
                isLoadingFact = false
            }
        }
    }
}

// Smooth depth animation for glass cards
class DepthPageTransformer : ViewPager2.PageTransformer {
    private val minScale = 0.92f
    private val minAlpha = 0.85f // Slightly higher alpha for glass effect

    override fun transformPage(page: View, position: Float) {
        page.apply {
            val pageWidth = width
            when {
                position < -1 -> alpha = 0f
                position <= 1 -> {
                    val scaleFactor = maxOf(minScale, 1 - kotlin.math.abs(position))
                    val vertMargin = pageWidth * (1 - scaleFactor) / 2
                    val horzMargin = pageWidth * (1 - scaleFactor) / 2
                    translationX = if (position < 0) {
                        horzMargin - vertMargin / 2
                    } else {
                        horzMargin + vertMargin / 2
                    }
                    scaleX = scaleFactor
                    scaleY = scaleFactor
                    alpha = (minAlpha + (((scaleFactor - minScale) / (1 - minScale)) * (1 - minAlpha)))
                }
                else -> alpha = 0f
            }
        }
    }
}