package com.example.factify

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar

class FavoritesActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var adapter: FavoritesAdapter
    private lateinit var emptyState: LinearLayout
    private lateinit var favCount: TextView
    private lateinit var db: FavoriteDatabase
    private var favorites: MutableList<String> = mutableListOf()

    companion object {
        private const val TAG = "FavoritesActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorites)

        Log.d(TAG, "onCreate started")

        // Initialize database
        try {
            db = FavoriteDatabase(this)
            Log.d(TAG, "Database initialized")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing database", e)
        }

        recycler = findViewById(R.id.favoritesRecycler)
        emptyState = findViewById(R.id.emptyState)
        favCount = findViewById(R.id.favCount)

        recycler.layoutManager = LinearLayoutManager(this)

        // Load favorites from database
        loadFavorites()

        adapter = FavoritesAdapter(favorites) { position ->
            try {
                // Get the fact to remove
                val factToRemove = favorites[position]
                Log.d(TAG, "Removing fact at position $position: $factToRemove")

                // Remove from database
                val rowsDeleted = db.removeFavorite(factToRemove)
                Log.d(TAG, "Rows deleted from DB: $rowsDeleted")

                // Remove from the list
                favorites.removeAt(position)

                // Notify adapter
                adapter.notifyItemRemoved(position)

                // Update UI immediately
                updateUI()

                Snackbar.make(recycler, "Removed from favorites", Snackbar.LENGTH_SHORT)
                    .setBackgroundTint(getColor(android.R.color.holo_red_dark))
                    .setTextColor(getColor(android.R.color.white))
                    .show()
            } catch (e: Exception) {
                Log.e(TAG, "Error removing favorite", e)
                Snackbar.make(recycler, "Error removing fact", Snackbar.LENGTH_SHORT).show()
            }
        }
        recycler.adapter = adapter

        updateUI()

        Log.d(TAG, "onCreate completed. Favorites count: ${favorites.size}")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume - Reloading favorites")

        // Reload favorites from database when returning to this screen
        loadFavorites()
        adapter.notifyDataSetChanged()
        updateUI()
    }

    private fun loadFavorites() {
        try {
            // Load all favorites from database
            favorites.clear()
            val loadedFavorites = db.getAllFavorites()
            favorites.addAll(loadedFavorites)

            Log.d(TAG, "Loaded ${favorites.size} favorites from database")
            favorites.forEachIndexed { index, fact ->
                Log.d(TAG, "Favorite $index: ${fact.take(50)}...")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading favorites", e)
        }
    }

    private fun updateUI() {
        // Update the count text
        val count = favorites.size
        favCount.text = "$count fact${if (count != 1) "s" else ""} saved"

        Log.d(TAG, "updateUI - Count: $count")

        // Show/hide empty state
        if (favorites.isEmpty()) {
            Log.d(TAG, "Showing empty state")
            recycler.visibility = View.GONE
            emptyState.visibility = View.VISIBLE
        } else {
            Log.d(TAG, "Showing favorites list")
            recycler.visibility = View.VISIBLE
            emptyState.visibility = View.GONE
        }
    }
}